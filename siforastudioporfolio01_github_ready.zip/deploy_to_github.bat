@echo off
git init
git add index.html README.md
git commit -m "Deploy SIFORA STUDIO Ai Marketing website"
git branch -M main
git remote remove origin 2>nul
git remote add origin https://github.com/munsifdesigner/siforastudioporfolio01.git
git push -u origin main --force
echo Successfully pushed to https://github.com/munsifdesigner/siforastudioporfolio01.git
pause
